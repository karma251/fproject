<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta name="viewport" content="initial-scale=1.0">
     
	<meta charset="UTF=8">
	<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
	<meat name="viewport"
			content="width-device-width, user-scalable=no, initial-scale=1.0, maximun-scale=1.0, minimum-scale=1.0">
	<mata http-equiv="X-UA-Compatible" content="ie=edge">	
	<title>Garbage Monitoring System</title>
	<link rel="stylesheet" href="<?php echo e(url('assets/css/app.css')); ?>">
	<link rel="stylesheet" type="text/css" href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
	 
	<link rel="stylesheet" type="text/css" href="<?php echo e(url('assets/css/main.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(url('assets/vendor/bootstrap/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('assets/vendor/fonts/circular-std/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('assets/libs/css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('assets/vendor/fonts/fontawesome/css/fontawesome-all.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('assets/vendor/datepicker/tempusdominus-bootstrap-4.css')); ?>" />



     


</head>
<body>

	<?php if(session('success_message')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success_message')); ?>

        </div>
      <?php endif; ?> 
	
	
	<?php echo $__env->yieldContent('content'); ?>
	<script src="<?php echo e(asset('js/app.js')); ?>">


	</script>	 
	

	<script src="<?php echo e(asset('vendor/jquery/jquery-3.3.1.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/bootstrap/js/bootstrap.bundle.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/slimscroll/jquery.slimscroll.js')); ?>"></script>
    <script src="<?php echo e(asset('libs/js/main-js.js')); ?>"></script>
	<<script src="<?php echo e(asset('vendor/datepicker/moment.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/datepicker/tempusdominus-bootstrap-4.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/datepicker/datepicker.js')); ?>"></script>
	
		

	
	 <script src="<?php echo e(asset('js/script.js')); ?>"></script> 	 

 
	<script src="<?php echo e(asset('js/datepicker.js')); ?>"></script>





 
	
   <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>  
        
</body>
</html><?php /**PATH C:\xampp\htdocs\blog\resources\views/layouts/template.blade.php ENDPATH**/ ?>