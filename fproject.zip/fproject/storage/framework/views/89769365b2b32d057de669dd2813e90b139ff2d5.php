<div class="dashboard-header">
            <nav class="navbar navbar-expand-lg bg-white fixed-top">
                <a class="navbar-brand" href="<?php echo e(route('home')); ?>">Garbage Monitoring System</a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse " id="navbarSupportedContent">
                    <ul class="navbar-nav ml-auto navbar-right-top">
                        <li class="nav-item">
                            <div id="custom-search" class="top-search-bar">
                                <input class="form-control" type="text" placeholder="Search..">
                            </div>
                        </li>

                        <li class="nav-item dropdown notification">
                            <a class="nav-link nav-icons" href="#" id="navbarDropdownMenuLink1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-fw fa-bell"></i> 
                                 
                                <?php if(auth()->user()->unreadnotifications->count()): ?><span class="badge badge-light"><?php echo e((auth()->user()->unreadnotifications->count())); ?></span> <span class="indicator"></span>
                            <?php endif; ?></a>
                            <ul class="dropdown-menu dropdown-menu-right notification-dropdown">
                                <li><a style="color: blue" href="<?php echo e(route('markAsRead')); ?>"class="dropdown-item">Mark all as Read</a></li>

                                <?php $__currentLoopData = auth()->user()->unReadNotifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <li style="background-color: lightgray">
                                     <a  class="dropdown-item" href=""><?php echo e($notification->data['data']); ?></a>
                                </li>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php $__currentLoopData = auth()->user()->readNotifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <li>
                                     <a  class="dropdown-item" href="#"><?php echo e($notification->data['data']); ?></a>
                                </li>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                                
                            </ul>
                        </li>


                       

                            
                            
                                
                       <?php if(auth()->guard()->guest()): ?>
                        <a class="nav-link nav-user-img" href="#" id="navbarDropdownMenuLink2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><img src="assets/images/avatar-1.jpg" alt="" class="user-avatar-md rounded-circle"></a>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('login')); ?>"> </a>
                            </li>
                            <?php if(Route::has('register')): ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                                </li>
                            <?php endif; ?>
                        <?php else: ?>
                            <li class="nav-item dropdown">
                                <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                    <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                                </a>

                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">

                                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        <?php echo e(__('Logout')); ?>

                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </div>
                            </li>
                        <?php endif; ?> 
                            
                        
                    </ul>
                </div>
            </nav>
               
         
                  
    </div> 








    <div class="nav-left-sidebar sidebar-dark">
            <div class="menu-list">
                <nav class="navbar navbar-expand-lg navbar-light">
                      
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarNav">
                        

                             <ul class="navbar-nav flex-column">
                             
                            
                            <a class="nav-link active" href="#"   aria-expanded="false"   aria-controls="submenu-1"><i class="fa fa-fw fa-user-circle"></i>Dashboard  </a>

                           <li class="nav-item">   
                                <a href="<?php echo e(route('home')); ?>" class="nav-link">
                                    <i class=" fas fa-location-arrow"></i>
                                    Bin Location
                                    <span class="badge badge-success">6</span>
                                </a>
                            </li>  

                             
                             <li class="nav-item">   
                                <a href="#" class="nav-link">
                                    <i class="fas fa-database"></i>
                                    Database
                                    <span class="badge badge-success">6</span>
                                </a>
                            </li>    
                            <li class="nav-item ">
                                <a class="nav-link" href="#" data-toggle="collapse" aria-expanded="false" data-target="#submenu-4" aria-controls="submenu-4"><i class="far fa-trash-alt"></i>Trash Collector</a>
                                <div id="submenu-4" class="collapse submenu" style="">
                                    <ul class="nav flex-column">
                                        <li class="nav-item">
                                            <a class="nav-link" href="<?php echo e(route('trashcollector.index')); ?>">Trash Collector Details</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="<?php echo e(route('trashcollector.add')); ?>">Add New</a>
                                        </li>
                                        
                                    </ul>
                                </div>
                            </li>

                              <li class="nav-item">
                                <a class="nav-link" href="#" data-toggle="collapse" aria-expanded="false" data-target="#submenu-7" aria-controls="submenu-7"><i class="fas fa-fw fa-inbox"></i>Announcement <span class="badge badge-secondary">New</span></a>
                                <div id="submenu-7" class="collapse submenu" style="">
                                    <ul class="nav flex-column">
                                        
                                         
                                        <li class="nav-item">
                                            <a class="nav-link" href="<?php echo e(route('announcement.addnotify')); ?>">Email Compose</a>
                                        </li>
                                        
                                    </ul>
                                </div>
                            </li>   

                              


                        </ul>
                    </div>    
                </nav>
            </div>


    </div>    
    
     
          <?php /**PATH C:\xampp\htdocs\blog\resources\views/layouts/menu.blade.php ENDPATH**/ ?>