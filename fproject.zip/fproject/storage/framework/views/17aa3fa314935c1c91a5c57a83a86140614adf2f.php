<?php $__env->startSection('content'); ?>
	<div class="dashboard-main-wrapper">           
        <?php echo $__env->make('layouts.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
         
        	<div class="dashboard-wrapper">
	            <div class="dashboasrd-finance">
	                <div class="container-fluid dashboard-content">
	                   <div class="card">
	                   		<div class="card-header">
	                   			<div class="card-title">
	                   				<h3>Edit Trash Collectors</h3>
	                   			</div>
	                   		</div>
	                   		<div class="card-body">
	                   			<form action="<?php echo e(route('trashcollector.update', $trashCollector->id)); ?>" method="POST">
	                   				<?php echo csrf_field(); ?>
	                   				 <?php echo method_field('put'); ?>
	                   				<div class="form-gorup">
	                   					<label for="name">Name</label>
	                   					<input type="text" value="<?php echo e($trashCollector->name); ?>" name="name" id="name" class="form-control">
	                   					
	                   				</div>
	                   				<div class="form-gorup">
	                   					<label for="name">Phone Number</label>
	                   					<input type="text" value="<?php echo e($trashCollector->phone); ?>" name="phone" id="phone" class="form-control">
	                   					
	                   				</div>
	                   				<div class="form-gorup">
	                   					<label for="name">Address</label>
	                   					<input type="text" value="<?php echo e($trashCollector->address); ?>" name="address" id="phone" class="form-control">
	                   					
	                   				</div>
	                   				<button class="btn btn-primary">Edit</button>
	                   				<a href="<?php echo e(route('trashcollector.index')); ?>" class="btn btn-danger">Cancel</a>
	                   			</form>	
	                   		</div>
	                   </div> 
	                </div>
	            </div>
	            

        </div>
    </div>   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blog\resources\views/trashcollector/edit.blade.php ENDPATH**/ ?>