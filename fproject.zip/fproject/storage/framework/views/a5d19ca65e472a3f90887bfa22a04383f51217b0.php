<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta name="viewport" content="initial-scale=1.0">
     
	<meta charset="UTF=8">
	<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
	<meat name="viewport"
			content="width-device-width, user-scalable=no, initial-scale=1.0, maximun-scale=1.0, minimum-scale=1.0">
	<mata http-equiv="X-UA-Compatible" content="ie=edge">	
	<title>Garbage Monitoring System</title>
	<link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
	<link href="https://maxcdn.bootstrap.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/main.css')); ?>">


</head>
<body>
	
	
	<?php echo $__env->yieldContent('content'); ?>
	 

	 

	<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBLu6F0t0SqCZvInhZ32XmBusEhbJJ7D44"
	 async defer></script>

	 <script src="<?php echo e(asset('js/script.js')); ?>"></script>

	 


	 	 

 
			
        
</body>
</html><?php /**PATH C:\xampp\htdocs\blog\resources\views/layouts/master.blade.php ENDPATH**/ ?>