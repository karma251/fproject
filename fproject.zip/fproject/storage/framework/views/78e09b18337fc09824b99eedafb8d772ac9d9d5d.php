<style>

      /* Always set the map height explicitly to define the size of the div
       * element that contains the map. */
/* 
      html,
body {
  height: 100%;
  margin: 0;
  padding: 0;
} */
#map {
  width: 90%;
    height: 100%;
    padding: 10px 10ox;
    margin: 0 auto;
}

.labels {
            color: black;
            background-color: white;
            font-family: "Lucida Grande", "Arial", sans-serif;
            font-size: 0.8em;
            font-weight: bold;
            text-align: center;
            width: 6em;
            border: 1px solid black;
            white-space: normal;
        }
     
    </style>





<?php $__env->startSection('content'); ?>
 <div class="dashboard-main-wrapper">
    <?php echo $__env->make('layouts.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="dashboard-wrapper">
        <div class="dashboard-finance">
           <!-- < <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3559.6774190245333!2d89.3918037145192!3d26.85021056924293!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x39e3cb2c210e611d%3A0x44c5cb2cd32b18d4!2sCollege%20of%20Science%20and%20Technology!5e0!3m2!1sen!2sbt!4v1583577397659!5m2!1sen!2sbt" width="100%" height="550" frameborder="0" style="border:0;" allowfullscreen=""></iframe> -->
            <div id="map"></div>
            <!-- <div class="container-fluid dashboard-content"></div> -->
            
            <?php echo e('Dashboard'); ?>


        </div>
    </div>      
 </div>

 <div class="footer p-3 mb-2 bg-dark text-white">


                            <div class="container-fluid">                                 
                                    <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 text-white">
                                         Copyright © 2020 FYP on garbage monitoring system. All rights reserved.  
                                    </div>
                                     
                                 
                            </div>
                        </div>

  


   
  <script>
     var loc = <?php  echo json_encode($data); ?>;
     console.log(loc);

  function initMap() {

 


  var map = new google.maps.Map(document.getElementById('map'), {
    zoom: 15,
    center: new google.maps.LatLng(26.920243, 89.520507),
    mapTypeId: google.maps.MapTypeId.ROADMAP,
  })



// You can have a loop here of all you marker points
// Begin loop
// bounds.extend(marker_point);
// End loop


var bounds = new google.maps.LatLngBounds();
  var infowindow = new google.maps.InfoWindow({})

  var marker, i

  var icon = {
    
    scaledSize: new google.maps.Size(40, 40), // scaled size
    origin: new google.maps.Point(0,0), // origin
    anchor: new google.maps.Point(0, 0),
    fillColor: '#00FF00',
    fillOpacity: 1.0,
    strokeColor: '#000000',
    strokeWeight: 1,
    scale: 2, // anchor
    
};

console.log(icon.url)
  for (i = 0; i < loc.length; i++) {
    if(loc[i]['located_in']=='comp'){ icon.url ="<?php echo e(asset('/images/pin.jpg')); ?>";}else{icon.url="<?php echo e(asset('/images/82-512.png')); ?>"}
    
      // icon.url = if(loc[i]['located_in']=='comp'){"<?php echo e(asset('/images/pin.png')); ?>"};
    marker = new google.maps.Marker({
      position: new google.maps.LatLng(loc[i]['latitude'], loc[i]['longitude']),
      icon: icon,      
      // label: { color: '#00aaff', fontWeight: 'bold', fontSize: '14px', text: 'Bin',padding:'10px' }  
      map: map,
    })


    bounds.extend(marker.position)

    google.maps.event.addListener(
      marker,
      'click',
      (function (marker, i) {
        return function () {
          infowindow.setContent('bin')
          infowindow.open(map, marker)
        }
      })(marker, i)
    )
  }
}

</script>

<script
  async
  defer
  src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAdeBd7eNkF7r99uYxJxuZB02wIzr-WSyg&callback=initMap"
></script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\blog\resources\views/home.blade.php ENDPATH**/ ?>