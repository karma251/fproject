<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Http\Requests\TrashCollectorRequest;
use App\TrashCollector;



class TrashController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

    public function index()
    {
          //
    }




    public function details()
    {
         $details = TrashCollector::paginate(10);
        return view('trashcollector.index', compact('details'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    

    public function trashcollector()
    {

        return view('trashcollector.add');
    }
     

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(TrashCollectorRequest $request)
    {
          
        $validator = Validator::make($request->all(),[
           
           'name' => 'required|min:5',
           'phone' => 'required|min:8',
           'address' => 'required|min:4',     
        ]);

        if ($validator->fails()){
            return back()->with('toast_error', $validator->messages()->all()[0])->withInput();
             
        }
        TrashCollector::create($request->all());
        return redirect()->route('trashcollector.index')->with('success','TrashCollector added successfully!');
        
    }

    /** 
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(TrashCollector $trashCollector)
    {
                  
        return view('trashcollector.edit', compact( 'trashCollector'));
    }



  //  public function edit(Product $product)
    //{
      //  return view('products.edit',compact('product'));
    //}

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, TrashCollector $trashCollector)
    {
         
         $request->validate([
            'name' => 'required',
            'phone' => 'required',
            'address' => 'required',
        ]);
         $trashCollector->update($request->all());
         return redirect()->route('trashcollector.index')->with('success', 'TrashCollector updated successfully');
    }



   // public function update(Request $request, Product $product)
  //  {
    //    $request->validate([
      //      'name' => 'required',
        //    'detail' => 'required',
        //]);
  
        //$product->update($request->all());
  
        //return redirect()->route('products.index')
          //              ->with('success','Product updated successfully');
    //}


    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(TrashCollector $trashCollector)
    {
         
        $trashCollector->delete();

        return redirect()->route('trashcollector.index')
                        ->with('success','TrashCollector deleted successfully');
    }

}

   // public function destroy(Product $product)
   // {
     //   $product->delete();
  
       // return redirect()->route('products.index')
         //               ->with('success','Product deleted successfully');
    //}


