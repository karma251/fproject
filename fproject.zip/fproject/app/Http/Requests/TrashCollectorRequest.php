<?php

namespace App\Http\Requests;


use Illuminate\Foundation\Http\FormRequest;

class TrashCollectorRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @retur  bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            //s'id' => 'required',
            'name' => 'required',
            'phone' => 'required',
            'address' => 'required'
        ];
    }
}
