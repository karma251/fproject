<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class Location extends Model
{

    protected $table = 'location';
    protected $fillable = ['bin_id','latitude','longitude','located_in'];

    protected $hidden = [];
}
