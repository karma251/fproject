<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class TrashCollector extends Model
{
    protected $fillable = ['id','name','phone','address'];

    protected $hidden = [];
}
