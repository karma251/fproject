window.$ = window.jQuery=require('jquery/dist/jquery.min')
require('./bootstrap');

 
require('./main-js')
require('bootstrap/dist/js/bootstrap.bundle')
require('bootstrap/dist/js/bootstrap.bundle')
require('jquery-slimscroll/jquery.slimscroll.min')
require('./dashboard')
