@extends('layouts.template')

@section('content')
	<div class="dashboard-main-wrapper">           
        @include('layouts.menu')
         
        	<div class="dashboard-wrapper">
	            <div class="dashboasrd-finance">
	                <div class="container-fluid dashboard-content">
	                   <div class="card">
	                   		<div class="card-header">
	                   			<div class="card-title">
	                   				<h3>Edit Trash Collectors</h3>
	                   			</div>
	                   		</div>
	                   		<div class="card-body">
	                   			<form action="{{ route('trashcollector.update', $trashCollector->id) }}" method="POST">
	                   				@csrf
	                   				 @method('put')
	                   				<div class="form-gorup">
	                   					<label for="name">Name</label>
	                   					<input type="text" value="{{$trashCollector->name}}" name="name" id="name" class="form-control">
	                   					
	                   				</div>
	                   				<div class="form-gorup">
	                   					<label for="name">Phone Number</label>
	                   					<input type="text" value="{{$trashCollector->phone}}" name="phone" id="phone" class="form-control">
	                   					
	                   				</div>
	                   				<div class="form-gorup">
	                   					<label for="name">Address</label>
	                   					<input type="text" value="{{$trashCollector->address}}" name="address" id="phone" class="form-control">
	                   					
	                   				</div>
	                   				<button class="btn btn-primary">Edit</button>
	                   				<a href="{{route('trashcollector.index')}}" class="btn btn-danger">Cancel</a>
	                   			</form>	
	                   		</div>
	                   </div> 
	                </div>
	            </div>
	            

        </div>
    </div>   
@endsection