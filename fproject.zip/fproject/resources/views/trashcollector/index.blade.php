@extends('layouts.template')

@section('content')
	<div class="dashboard-main-wrapper">
		@include('layouts.menu')
		<div class="dashboard-wrapper">
			<div class="container-fluid dashboard-content">
				<div class="card">
					<div class="card-header">
						<div class="card-title">
							<h5>Trash Collector Profile <a href="{{route('trashcollector.add')}}"   class="btn btn-primary btn-xs">
							<i class=" fas fa-plus-circle"></i> Add New</a></h5>

						</div>
					</div>
					
					<div class="card-body">
						<table class="table table-striped table-bordered">
							<thead>
								<tr>
									<th>ID</th>
									<th>Name</th>
									<th>Phone Number</th>
									<th>Address</th>
									
								</tr>
							</thead>
							
							<tbody>
								@foreach($details as $row)
								<tr>
									<td>{{$row->id}}</td>
									<td>{{$row->name}}</td>
									<td>{{$row->phone}}</td>
									<td>{{$row->address}}</td>
									<td>
										<div class="btn-group">
											<a href="{{route('trashcollector.edit', $row->id)}}" class="btn btn-info" title="Edit"><i class="fas fa-edit"></i></a>
											<a href="{{route('trashcollector.destroy', $row->id)}}"  onclick="event.preventDefault(); document.getElementById('formDelete').submit();" class="btn btn-danger" title="Delete"><i class="fas fa-trash"></i></a>
											<form id="formDelete" action="{{route('trashcollector.destroy', $row->id)}}" method="POST" style="display: none;">
												@csrf
												@method('delete')
												
											</form>
										</div>									
									</td>
								</tr>
								@endforeach
							</tbody>
						</table>
						<div class="mt-2">
							{{$details->links()}}
						</div>
						
					</div>
				</div>		
			</div>
			<div class="footer p-3 mb-2 bg-dark text-white">
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
                                          Copyright © 2020 FYP on garbage monitoring system. All rights reserved. 
                                    </div>
                                     
                                </div>
                            </div>
                        </div>

		</div>
	</div>
@endsection