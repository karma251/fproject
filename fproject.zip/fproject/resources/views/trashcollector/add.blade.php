@extends('layouts.template')

@section('content')
	<div class="dashboard-main-wrapper">           
        @include('layouts.menu')
         
        	<div class="dashboard-wrapper">
	            <div class="dashboasrd-finance">
	                <div class="container-fluid dashboard-content">
	                   <div class="card">
	                   		<div class="card-header">
	                   			<div class="card-title">
	                   				<h3>Add New Trash Collector</h3>
	                   			</div>
	                   		</div>
	                   		<div class="card-body">
	                   			
	                   			<form action="{{route('trashcollector.store')}}" method="post">
	                   				@csrf
	                   				<div class="form-gorup">
	                   					<label for="name">Name</label>
	                   					<input type="text" name="name" id="name" class="form-control">
	                   					
	                   				</div>
	                   				<div class="form-gorup">
	                   					<label for="name">Phone Number</label>
	                   					<input type="text" name="phone" id="phone" class="form-control">
	                   					
	                   				</div>
	                   				<div class="form-gorup">
	                   					<label for="name">Address</label>
	                   					<input type="text" name="address" id="phone" class="form-control">
	                   					
	                   				</div>
	                   				<button class="btn btn-primary">Add New</button>
	                   			</form>	
	                   		</div>
	                   </div> 
	                   @include('sweetalert::alert')  

	                </div>
	            </div>
	            <div class="footer p-3 mb-2 bg-dark text-white">
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
                                          Copyright © 2020 FYP on garbage monitoring system. All rights reserved. 
                                    </div>
                                    
                                </div>
                            </div>
                        </div>

        </div>

    </div>   
@endsection