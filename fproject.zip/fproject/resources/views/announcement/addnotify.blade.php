@extends('layouts.template')

@section('content')
	<div class="dashboard-main-wrapper">           
        @include('layouts.menu')
         
        	<div class="dashboard-wrapper">
	            <div class="dashboasrd-finance">
	                <div class="container-fluid dashboard-content">

	                   <div class="card">
	                   		<div class="card-header p-3 mb-2 bg-dark text-white">

	                   			<div class="card-title">
	                   				<h3>Announcements Section</h3>
	                   			</div>
	                   		</div>
	                   		<div class="card-body bg-light  ">

                             
                            <div class="card-body">
                                <div id="carouselExampleIndicators1" class="carousel slide" data-ride="carousel">
                                    <ol class="carousel-indicators">
                                        <li data-target="#carouselExampleIndicators1" data-slide-to="0" class="active"></li>
                                        <li data-target="#carouselExampleIndicators1" data-slide-to="1"></li>
                                        <li data-target="#carouselExampleIndicators1" data-slide-to="2"></li>
                                    </ol>
                                    <div class="carousel-inner">
                                        <div class="carousel-item active">
                                            <img class="d-block w-100" src="../assets/images/img-1.png" alt="First slide">
                                            <div class="carousel-caption d-none d-md-block">
                                                <h3 class="text-white">Heading Title Carousel</h3>
                                                <p>Mauris fermentum elementum ligula in efficitur. Aliquam id congue lorem. Proin consectetur feugiat enim ut luctus. Aliquam pellentesque ut tellus ultricies bibendum.</p>
                                            </div>
                                        </div>
                                        <div class="carousel-item">
                                            <img class="d-block w-100" src="../assets/images/img-2.png" alt="Second slide">
                                            <div class="carousel-caption d-none d-md-block">
                                                <h3 class="text-white">Heading Title Carousel</h3>
                                                <p>Mauris fermentum elementum ligula in efficitur. Aliquam id congue lorem. Proin consectetur feugiat enim ut luctus. Aliquam pellentesque ut tellus ultricies bibendum.</p>
                                            </div>
                                        </div>
                                        <div class="carousel-item">
                                            <img class="d-block w-100" src="../assets/images/img-3.png" alt="Third slide">
                                            <div class="carousel-caption d-none d-md-block">
                                                <h3 class="text-white">Heading Title Carousel</h3>
                                                <p>Mauris fermentum elementum ligula in efficitur. Aliquam id congue lorem. Proin consectetur feugiat enim ut luctus. Aliquam pellentesque ut tellus ultricies bibendum.</p>
                                            </div>
                                        </div>
                                    </div>
                                    <a class="carousel-control-prev" href="#carouselExampleIndicators1" role="button" data-slide="prev">
                                      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                       <span class="sr-only">Previous</span>  </a>
                                    <a class="carousel-control-next" href="#carouselExampleIndicators1" role="button" data-slide="next">
                                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                            <span class="sr-only">Next</span>  </a>
                                </div>
                            </div>

	                   			<form action="{{route('announcement.addnotify')}}" method="post">
	                   				@csrf


	                   				<div class="form-gorup">
	                   					<div class="card-body border-top">
                                            <div class="form-gorup">
                                        <label for="name">Announce Date</label>
                                        <input type="text" name="date" id="phone" class="form-control">
                                        
                                    </div>
                                   
                                
									<div class="form-gorup">
	                   					<label for="name">Add Announcements</label>
	                   					<span class="border-top"><textarea type="text" name="name" id="name" class="form-control"></textarea></span>
	                   					 
                                       <!-- <button type="button" class="btn btn-primary" data-toggle="tooltip" data-placement="top" title="Click here to send">
                                                Go!
                                            </button>-->
                                            <button class="btn btn-primary" data-toggle="tooltip" title="Click here to send">Go!</button>
	                   					
	                   				</div>

	                   				 
	                   				
	                   				</div>
	                   			</form>	

	                   		</div>
	                   </div> 

	                </div>
	            </div>
            <div class="footer p-3 mb-2 bg-dark text-white">
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
                                          Copyright © 2020 FYP on garbage monitoring system. All rights reserved. 
                                    </div>
                                     
                                </div>
                            </div>
                        </div>

        </div>


    </div>   
@endsection