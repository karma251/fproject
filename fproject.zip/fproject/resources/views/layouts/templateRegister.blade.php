<!doctype html>
<html lang="pt-br">
<head>
	<meta charset="utf-8">
	 
	<meta name="viewport"
	content="width-device.width, user-scalable=no, initial-scalale=1.0, maximum-scale=1.0, minimun-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie-edge">
	<title>Document</title>
	<link rel="stylesheet" type="text/css" href="{{asset('css/app.css')}} ">
    <link rel="stylesheet" href="{{ url('assets/vendor/bootstrap/css/bootstrap.min.css') }}">
    <link rel="stylesheet" href="{{ url('assets/vendor/bootstrap/css/bootstrap.min.css') }}">
    <link href="{{ url('assets/vendor/fonts/circular-std/style.css" rel="stylesheet') }}">
    <link rel="stylesheet" href="{{ url('assets/libs/css/style.css') }}">
    <link rel="stylesheet" href="{{ url('assets/vendor/fonts/fontawesome/css/fontawesome-all.css') }}">
</head>	
<style>
	<style>
    html,
    body {
        height: 100%;
    }

    body {
        display: -ms-flexbox;
        display: flex;
        -ms-flex-align: center;
        align-items: center;
        padding-top: 40px;
        padding-bottom: 40px;
    }
    </style>
<body>
	@yield('content')
	<script type="{{asset('js/app.js')}}"></script>
	
</body>
</html>