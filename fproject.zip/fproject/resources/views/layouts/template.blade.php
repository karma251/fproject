<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta name="viewport" content="initial-scale=1.0">
     
	<meta charset="UTF=8">
	<meta name="csrf-token" content="{{csrf_token()}}">
	<meat name="viewport"
			content="width-device-width, user-scalable=no, initial-scale=1.0, maximun-scale=1.0, minimum-scale=1.0">
	<mata http-equiv="X-UA-Compatible" content="ie=edge">	
	<title>Garbage Monitoring System</title>
	<link rel="stylesheet" href="{{ url('assets/css/app.css') }}">
	<link rel="stylesheet" type="text/css" href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
	 
	<link rel="stylesheet" type="text/css" href="{{ url('assets/css/main.css') }}">
	<link rel="stylesheet" href="{{ url('assets/vendor/bootstrap/css/bootstrap.min.css') }}">
    <link rel="stylesheet" href="{{ url('assets/vendor/fonts/circular-std/style.css') }}">
    <link rel="stylesheet" href="{{ url('assets/libs/css/style.css') }}">
    <link rel="stylesheet" href="{{ url('assets/vendor/fonts/fontawesome/css/fontawesome-all.css') }}">
    <link rel="stylesheet" href="{{ url('assets/vendor/datepicker/tempusdominus-bootstrap-4.css') }}" />



     


</head>
<body>

	@if (session('success_message'))
        <div class="alert alert-success">
            {{session('success_message')}}
        </div>
      @endif 
	
	
	@yield('content')
	<script src="{{asset('js/app.js')}}">


	</script>	 
	

	<script src="{{asset('vendor/jquery/jquery-3.3.1.min.js')}}"></script>
    <script src="{{asset('vendor/bootstrap/js/bootstrap.bundle.js')}}"></script>
    <script src="{{asset('vendor/slimscroll/jquery.slimscroll.js')}}"></script>
    <script src="{{asset('libs/js/main-js.js')}}"></script>
	<<script src="{{asset('vendor/datepicker/moment.js')}}"></script>
    <script src="{{asset('vendor/datepicker/tempusdominus-bootstrap-4.js')}}"></script>
    <script src="{{asset('vendor/datepicker/datepicker.js')}}"></script>
	
		

	
	 <script src="{{asset('js/script.js')}}"></script> 	 

 
	<script src="{{asset('js/datepicker.js')}}"></script>





 
	
   @include('sweetalert::alert')  
        
</body>
</html>