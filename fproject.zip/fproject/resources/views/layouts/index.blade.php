<!DOCTYPE html>
<html>
  <head>
    <meta name="viewport" content="initial-scale=1.0">
     
  <meta charset="UTF=8">
  <meta name="csrf-token" content="{{csrf_token()}}">
  <meat name="viewport"
      content="width-device-width, user-scalable=no, initial-scale=1.0, maximun-scale=1.0, minimum-scale=1.0">
  <mata http-equiv="X-UA-Compatible" content="ie=edge"> 
  <title>Garbage Monitoring System</title>
  <link rel="stylesheet" href="{{asset('css/app.css')}}">
   
     
  </head>
  <body>
       
    @yield('content')
  <script src="{{asset('js/app.js')}}"></script>
     

    
    </script>
    <script async defer
        src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBUPjjT9rd2yD6Ug8R4hcJSczCPWZiQZcw&libraries=visualization&callback=initMap">
    </script>
  </body>
</html>